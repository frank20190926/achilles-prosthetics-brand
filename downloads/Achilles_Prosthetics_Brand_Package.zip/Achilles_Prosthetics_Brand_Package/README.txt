Achilles Prosthetics and Orthotics
Identity refresh · production package

01_Vector_Masters/   17 masters in SVG, PDF, AI and EPS. Outlined paths only: no live type,
                     no fonts to install. The .ai files are PDF-compatible Illustrator files.
02_PNG_Transparent/  Lockups 3200 px wide, marks 2048 px, transparent ground.
03_Favicon/          512, 192 and 64 px (standard mark) and 32, 16 px (small-size cut).
04_Presentation_Boards/  Four boards, 3200 x 2400 px.
Achilles_Brand_Style_Sheet_and_Proposal.pdf   The four boards as one PDF.

File names
  horizontal / stacked     lockup
  light                    Carbon Black + Clinical Maroon, for white and paper grounds
  dark                     white, on Clinical Maroon
  carbon                   white + Dark-Ground Maroon, on Carbon Black
  black                    one-color black
  _and                     descriptor set as PROSTHETICS AND ORTHOTICS instead of the ampersand
  mark_color / black / white   strut mark alone
  icon_mark                app icon and avatar tile
  favicon_small            small-size cut for 16 to 32 px

Colors
  Clinical Maroon      #6E1423   RGB 110 20 35    CMYK 20 93 73 44   Pantone 188 C
  Dark-Ground Maroon   #C2364F   RGB 194 54 79    CMYK 6 91 54 7     Pantone 7636 C
  Carbon Black         #111315   RGB 17 19 21     CMYK 77 71 63 75   Pantone Black 6 C
  Pure White           #FFFFFF
  Pantone references are nearest coated matches; confirm against a swatch book before press.

Typefaces (SIL Open Font License 1.1, free for commercial use)
  Plus Jakarta Sans    headings and wordmark     fonts.google.com/specimen/Plus+Jakarta+Sans
  Inter                body copy and interface   fonts.google.com/specimen/Inter
  IBM Plex Mono        optional accent           fonts.google.com/specimen/IBM+Plex+Mono
